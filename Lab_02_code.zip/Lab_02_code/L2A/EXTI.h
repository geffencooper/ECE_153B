/*
 * ECE 153B - Winter 2021
 *
 * Name(s): Geffen Cooper
 * Section: Wednesday 7:00 - 9:50 PM
 * Lab: 1B
 */

#ifndef __STM32L476G_DISCOVERY_EXTI_H
#define __STM32L476G_DISCOVERY_EXTI_H

#include "stm32l476xx.h"

void EXTI_Init(void);

#endif
