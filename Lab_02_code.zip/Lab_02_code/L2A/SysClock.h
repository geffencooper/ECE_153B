/*
 * ECE 153B - Summer 2020
 *
 * Name(s):
 * Section:
 * Lab: 1B
 */

#ifndef __STM32L476G_DISCOVERY_CLOCK_H
#define __STM32L476G_DISCOVERY_CLOCK_H

#include "stm32l476xx.h"

void System_Clock_Init(void);

#endif
